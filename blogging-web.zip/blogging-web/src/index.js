import React from 'react';
import './index.css';
import App from './App';
import { BrowserRouter } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
//bostp    = npm
import 'bootstrap/dist/css/bootstrap.min.css';
//toastify  = npm
import 'react-toastify/dist/ReactToastify.css';
  // <BrowserRouter>
  // react ReactDOM = npm  
import ReactDOM from 'react-dom/client';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <BrowserRouter>
  <ToastContainer/>
    <App />
  </BrowserRouter>
);

